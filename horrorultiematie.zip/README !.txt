HORRORULTİMATİE trojan by @reyiz_bey

-------------------------------------------------------------------------------------------
warnıng ı dont your pc run ! your pc demage !

pls your virtual machine run !

